<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
return ['project-id-version'=>'PhotoProof','report-msgid-bugs-to'=>'','pot-creation-date'=>'2026-04-02 14:50+0000','po-revision-date'=>'2026-04-02 15:17+0000','last-translator'=>'','language-team'=>'Spanish (Spain)','language'=>'es_ES','plural-forms'=>'nplurals=2; plural=n != 1;','mime-version'=>'1.0','content-type'=>'text/plain; charset=UTF-8','content-transfer-encoding'=>'8bit','x-generator'=>'Loco https://localise.biz/','x-loco-version'=>'2.8.3; wp-6.9.4; php-8.3.1','x-domain'=>'photoproof','messages'=>[]];
